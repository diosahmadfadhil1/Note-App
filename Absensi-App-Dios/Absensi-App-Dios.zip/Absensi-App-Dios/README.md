# ToDoTaskJetpackCompose

This is a simple ToDo app for task management developed with jetpack compose and kotlin language.

In this project, mvvm architecture, room and dagger-hilt libraries are used. 

https://user-images.githubusercontent.com/57577286/159474462-b63c8734-1e86-415b-b090-79d822ef73af.mp4

