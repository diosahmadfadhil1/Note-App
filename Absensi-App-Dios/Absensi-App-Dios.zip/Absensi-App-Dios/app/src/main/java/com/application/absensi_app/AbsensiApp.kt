package com.application.absensi_app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AbsensiApp : Application() {
}